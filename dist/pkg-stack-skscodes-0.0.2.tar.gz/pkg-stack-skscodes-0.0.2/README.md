# stack_ops package
This is a hand made feature 'stack' with unittest. There are two implementations:    
1. In script, stack.py  
2. By installing my uploaded package 'pkg_stack' through pip

== Execution by installing package 'pkg_stack':     
To install package 'pkg_stack':          
pip install pkg-stack-skscodes   

To import:     
import pkg_stack     


== Regular/Direct source code execution:     
to activate venv:          
source venv/bin/activate        

run demo:     
python mystack.py    

run unittest:     
python stack_unittest.py    

